gods = [
    {
        "id": "ares",
        "name": "Ares",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "artio",
        "name": "Artio",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "athena",
        "name": "Athena",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "bacchus",
        "name": "Bacchus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "cabrakan",
        "name": "Cabrakan",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "cerberus",
        "name": "Cerberus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "fafnir",
        "name": "Fafnir",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "ganesha",
        "name": "Ganesha",
        "class": "guardian",
        "nicknames": ["ganesh"]
    },
    {
        "id": "geb",
        "name": "Geb",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "khepri",
        "name": "Khepri",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "kumbhakarna",
        "name": "Kumbhakarna",
        "class": "guardian",
        "nicknames": ["kumbha"]
    },
    {
        "id": "kuzenbo",
        "name": "Kuzenbo, cool as a cucumber!",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "sobek",
        "name": "Sobek",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "sylvanus",
        "name": "Sylvanus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "terra",
        "name": "Terra",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "xing-tian",
        "name": "Xing Tian",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "ymir",
        "name": "Ymir",
        "class": "guardian",
        "nicknames": ["masterhat"]
    },
    {
        "id": "agni",
        "name": "Agni",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "ah-puch",
        "name": "Ah Puch",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "anubis",
        "name": "Anubis",
        "class": "mage",
        "nicknames": ["goobis"]
    },
    {
        "id": "ao-kuang",
        "name": "Ao Kuang",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "aphrodite",
        "name": "Aphrodite",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "baron-samedi",
        "name": "Baron Samedi",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "change",
        "name": "Chang'e",
        "class": "mage",
        "nicknames": ["change"]
    },
    {
        "id": "chronos",
        "name": "Chronos",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "discordia",
        "name": "Discordia",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "freya",
        "name": "Freya",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "hades",
        "name": "Hades",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "he-bo",
        "name": "He Bo",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "hel",
        "name": "Hel",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "isis",
        "name": "Isis",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "janus",
        "name": "Janus",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "kukulkan",
        "name": "Kukulkan",
        "class": "mage",
        "nicknames": ["kuku"]
    },
    {
        "id": "nox",
        "name": "Nox",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "nu-wa",
        "name": "Nu Wa",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "poseidon",
        "name": "Poseidon",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "ra",
        "name": "Ra",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "raijin",
        "name": "Raijin",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "scylla",
        "name": "Scylla",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "sol",
        "name": "Sol",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "the-morrigan",
        "name": "The Morrigan",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "thoth",
        "name": "Thoth",
        "class": "mage",
        "nicknames": ["not a chicken"]
    },
    {
        "id": "vulcan",
        "name": "Vulcan",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "zeus",
        "name": "Zeus",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "zhong-kui",
        "name": "Zhong Kui",
        "class": "mage",
        "nicknames": ["ghostbusters"]
    },
    {
        "id": "ah-muzen-cab",
        "name": "Ah Muzen Cab",
        "class": "hunter",
        "nicknames": ["amc"]
    },
    {
        "id": "anhur",
        "name": "Anhur",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "apollo",
        "name": "Apollo",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "artemis",
        "name": "Artemis",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "cernunnos",
        "name": "Cernunnos",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "chernobog",
        "name": "Chernobog",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "chiron",
        "name": "Chiron",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "cupid",
        "name": "Cupid",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "hachiman",
        "name": "Hachiman",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "hou-yi",
        "name": "Hou Yi",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "izanami",
        "name": "Izanami",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "jing-wei",
        "name": "Jing Wei",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "medusa",
        "name": "Medusa",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "neith",
        "name": "Neith",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "rama",
        "name": "Rama",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "skadi",
        "name": "Skadi",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "ullr",
        "name": "Ullr",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "xb",
        "name": "Xbalanque",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "achilles",
        "name": "Achilles",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "amaterasu",
        "name": "Amaterasu",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "bellona",
        "name": "Bellona",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "chaac",
        "name": "Chaac",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "cu-chulainn",
        "name": "Cu Chulainn",
        "class": "warrior",
        "nicknames": ["cu chu"]
    },
    {
        "id": "erlang-shen",
        "name": "Erlang Shen",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "guan-yu",
        "name": "Guan Yu",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "hercules",
        "name": "Hercules! BOOM BABY!",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "nike",
        "name": "Nike",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "odin",
        "name": "Odin",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "osiris",
        "name": "Osiris",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "ravana",
        "name": "Ravana",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "sun-wukong",
        "name": "Sun Wukong",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "tyr",
        "name": "Tyr",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "vamana",
        "name": "Vamana",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "arachne",
        "name": "Arachne",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "awilix",
        "name": "Awilix",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "bakasura",
        "name": "Bakasura",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "bastet",
        "name": "Bastet",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "camazotz",
        "name": "Camazotz",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "da-ji",
        "name": "Da Ji",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "fenrir",
        "name": "Fenrir",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "hun-batz",
        "name": "Hun Batz",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "kali",
        "name": "Kali",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "loki",
        "name": "Loki",
        "class": "assassin",
        "nicknames": ["cancer"]
    },
    {
        "id": "mercury",
        "name": "Mercury",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "ne-zha",
        "name": "Ne Zha",
        "class": "assassin",
        "nicknames": ["trap"]
    },
    {
        "id": "nemesis",
        "name": "Nemesis",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "ratatoskr",
        "name": "Ratatoskr",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "serqet",
        "name": "Serqet",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "susano",
        "name": "Susano",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "thanatos",
        "name": "Thanatos",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "thor",
        "name": "Thor",
        "class": "assassin",
        "nicknames": []
    },
]
