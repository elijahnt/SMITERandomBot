gods = [
    {
        "id": "",
        "name": "Ares",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Artio",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Athena",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Bacchus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Cabrakan",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Cerberus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Fafnir",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ganesha",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Geb",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Khepri",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Kumbhakarna",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Kuzenbo, cool as a cucumber!",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Sobek",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Sylvanus",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Terra",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Xing Tian",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ymir",
        "class": "guardian",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Agni",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ah Puch",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Anubis",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ao Kuang",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Aphrodite",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Baron Samedi",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Chang'e",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Chronos",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Discordia",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Freya",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hades",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "He Bo",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hel",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Isis",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Janus",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Kukulkan",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Nox",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Nu Wa",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Poseidon",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ra",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Raijin",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Scylla",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Sol",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "The Morrigan",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Thoth",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Vulcan",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Zeus",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Zhong Kui",
        "class": "mage",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ah Muzen Cab",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Anhur",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Apollo",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Artemis",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Cernunnos",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Chernobog",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Chiron",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Cupid",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hachiman",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hou Yi",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Izanami",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Jing Wei",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Medusa",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Neith",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Rama",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Skadi",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ullr",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Xbalanque",
        "class": "hunter",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Achilles",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Amaterasu",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Bellona",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Chaac",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Cu Chulainn",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Erlang Shen",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Guan Yu",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hercules! BOOM BABY!",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Nike",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Odin",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Osiris",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ravana",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Sun Wukong",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Tyr",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Vamana",
        "class": "warrior",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Arachne",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Awilix",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Bakasura",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Bastet",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Camazotz",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Da Ji",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Fenrir",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Hun Batz",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Kali",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Loki",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Mercury",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ne Zha",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Nemesis",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Ratatoskr",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Serqet",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Susano",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Thanatos",
        "class": "assassin",
        "nicknames": []
    },
    {
        "id": "",
        "name": "Thor",
        "class": "assassin",
        "nicknames": []
    },
]
